### This project analyzes the dataset of XYZ supermarket .
* Dataset gathered from three different branches (A, B and C) representing three cities(Lagos, Abuja and Port Harcourt) respectively.
* The three dataset set was merged to have a single dataset. 
* Analysis also checks for missing files.
* Datetime features was used  to convert a column to a datetime datatype, for easy extraction of some date and time           features.
* Visualization was done using Seaborn library and nicely formatted with some of the attributes. 
* Visualization includes the use of FacetGrid for multiple plot grid for plotting conditional relationships.
